// Sample test case for class, constructor, input/output

class MyClass begin
    var x: integer;
    constructor() begin
        readln(x);
    end
    procedure printX() begin
        writeln(x);
    end
end

var obj: MyClass;
obj := new MyClass();
obj.printX();
