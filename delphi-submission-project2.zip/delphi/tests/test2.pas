// Sample test case for encapsulation and destructor

class Counter begin
    private var value: integer;
    constructor() begin
        value := 0;
    end
    procedure increment() begin
        value := value + 1;
    end
    procedure print() begin
        writeln(value);
    end
    destructor() begin
        writeln(0);
    end
end

var c: Counter;
c := new Counter();
c.increment();
c.print();
// Destructor will be called automatically at program end
