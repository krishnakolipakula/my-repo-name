// Sample test case for inheritance (bonus)

class Animal begin
    public var name: integer;
    constructor() begin
        readln(name);
    end
    procedure speak() begin
        writeln(name);
    end
end

class Dog : Animal begin
    procedure speak() begin
        writeln(name);
    end
end

var d: Dog;
d := new Dog();
d.speak();
