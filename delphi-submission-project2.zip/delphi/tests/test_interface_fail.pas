interface Printable
begin
  procedure display();
end

class BadClass implements Printable
begin
  public var x: integer;
  
  constructor()
  begin
    x := 1;
  end
end

var b: BadClass;
b := new BadClass();
