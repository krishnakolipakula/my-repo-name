class Test
begin
  public var x: integer;
  constructor()
  begin
    x := 99;
  end
end

var t: Test;

begin
  t := new Test();
  writeln(t.x);
end.
