interface Printable
begin
  procedure display();
end

class Message implements Printable
begin
  public var text: integer;
  
  constructor(value: integer)
  begin
    text := value;
  end
  
  procedure display()
  begin
    writeln(text);
  end
  
  destructor()
  begin
    writeln(0);
  end
end

var msg: Message;

msg := new Message(100);
msg.display();
