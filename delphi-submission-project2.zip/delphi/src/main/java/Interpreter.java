import java.util.*;

public class Interpreter extends delphiBaseVisitor<Object> {

    static class BreakSignal extends RuntimeException {}
    static class ContinueSignal extends RuntimeException {}

    static class InterfaceDef {
        String name;
        Set<String> requiredMethods = new HashSet<>();
    }

    static class RoutineDef {
        String name;
        List<String> params = new ArrayList<>();
        delphiParser.BlockContext block;
        boolean function;
    }

    static class ClassDef {
        String name;
        String superName;
        List<delphiParser.FieldDeclContext> fields = new ArrayList<>();
        Map<String, Boolean> fieldVisibility = new HashMap<>(); // true = private
        delphiParser.ConstructorDeclContext constructor;
        delphiParser.DestructorDeclContext destructor;
        Map<String, delphiParser.MethodDeclContext> methods = new HashMap<>();
    }

    static class Instance {
        ClassDef klass;
        Map<String, Object> fields = new HashMap<>();
        Instance(ClassDef k) { klass = k; }
    }

    private final Map<String, InterfaceDef> interfaces = new HashMap<>();
    private final Map<String, RoutineDef> routines = new HashMap<>();
    private final Map<String, ClassDef> classes = new HashMap<>();
    private final Map<String, Object> globals = new HashMap<>();
    private final List<Instance> allInstances = new ArrayList<>();
    private final Deque<Map<String,Object>> scopes = new ArrayDeque<>();
    private Instance currentThis = null;
    private final Scanner scanner = new Scanner(System.in);

    private void pushScope() {
        scopes.push(new HashMap<>());
    }

    private void popScope() {
        scopes.pop();
    }

    private void declareVariable(String id, Object value) {
        if (!scopes.isEmpty()) scopes.peek().put(id, value);
        else globals.put(id, value);
    }

    private boolean assignToExistingLocal(String id, Object value) {
        for (Map<String, Object> scope : scopes) {
            if (scope.containsKey(id)) {
                scope.put(id, value);
                return true;
            }
        }
        return false;
    }

    private Object lookup(String id) {
        for (Map<String, Object> scope : scopes) {
            if (scope.containsKey(id)) return scope.get(id);
        }
        if (currentThis != null && currentThis.fields.containsKey(id)) return currentThis.fields.get(id);
        return globals.get(id);
    }

    private void assign(String id, Object value) {
        if (assignToExistingLocal(id, value)) return;
        if (currentThis != null && currentThis.fields.containsKey(id)) {
            currentThis.fields.put(id, value);
            return;
        }
        globals.put(id, value);
    }

    private int asInt(Object value) {
        return value == null ? 0 : ((Number) value).intValue();
    }

    private boolean isTruthy(Object value) {
        if (value == null) return false;
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof String) return !((String) value).isEmpty();
        return true;
    }

    private List<Object> evalArgs(delphiParser.ArgListContext argList) {
        List<Object> values = new ArrayList<>();
        if (argList == null) return values;
        for (var e : argList.expr()) values.add(visit(e));
        return values;
    }

    private Object callRoutine(String name, delphiParser.ArgListContext argList, boolean mustReturn) {
        RoutineDef routine = routines.get(name);
        if (routine == null) throw new RuntimeException("Unknown routine: " + name);
        if (mustReturn && !routine.function) throw new RuntimeException("Routine is not a function: " + name);

        List<Object> args = evalArgs(argList);
        if (args.size() != routine.params.size()) {
            throw new RuntimeException("Argument count mismatch for " + name + ": expected " + routine.params.size() + ", got " + args.size());
        }

        Deque<Map<String, Object>> savedScopes = new ArrayDeque<>(scopes);
        Instance savedThis = currentThis;
        scopes.clear();
        currentThis = null;

        pushScope();
        if (routine.function) scopes.peek().put(name, 0);
        for (int i = 0; i < routine.params.size(); i++) {
            scopes.peek().put(routine.params.get(i), args.get(i));
        }

        try {
            visit(routine.block);
            if (routine.function) return lookup(name);
            return null;
        } finally {
            scopes.clear();
            scopes.addAll(savedScopes);
            currentThis = savedThis;
        }
    }

    @Override
    public Object visitProgram(delphiParser.ProgramContext ctx) {
        try {
            for (var d : ctx.topLevelDecl()) visit(d);
            for (var s : ctx.stmt()) visit(s);
            if (ctx.mainBlock() != null) visitMainBlock(ctx.mainBlock());
        } catch (BreakSignal | ContinueSignal signal) {
            throw new RuntimeException("break/continue used outside loop");
        } finally {
            // Call destructors for all created objects
            for (Instance inst : allInstances) {
                if (inst.klass.destructor != null) {
                    Instance prevThis = currentThis;
                    currentThis = inst;
                    pushScope();
                    visit(inst.klass.destructor.block());
                    popScope();
                    currentThis = prevThis;
                }
            }
        }
        return null;
    }

    @Override
    public Object visitTopLevelDecl(delphiParser.TopLevelDeclContext ctx) {
        if (ctx.interfaceDecl() != null) return visitInterfaceDecl(ctx.interfaceDecl());
        if (ctx.classDecl() != null) return visitClassDecl(ctx.classDecl());
        if (ctx.procedureDecl() != null) return visitProcedureDecl(ctx.procedureDecl());
        if (ctx.functionDecl() != null) return visitFunctionDecl(ctx.functionDecl());
        return null;
    }

    @Override
    public Object visitProcedureDecl(delphiParser.ProcedureDeclContext ctx) {
        RoutineDef r = new RoutineDef();
        r.name = ctx.ID().getText();
        r.function = false;
        r.block = ctx.block();
        if (ctx.paramList() != null) {
            for (var p : ctx.paramList().param()) r.params.add(p.ID().getText());
        }
        routines.put(r.name, r);
        return null;
    }

    @Override
    public Object visitFunctionDecl(delphiParser.FunctionDeclContext ctx) {
        RoutineDef r = new RoutineDef();
        r.name = ctx.ID().getText();
        r.function = true;
        r.block = ctx.block();
        if (ctx.paramList() != null) {
            for (var p : ctx.paramList().param()) r.params.add(p.ID().getText());
        }
        routines.put(r.name, r);
        return null;
    }

    @Override
    public Object visitInterfaceDecl(delphiParser.InterfaceDeclContext ctx) {
        InterfaceDef iface = new InterfaceDef();
        iface.name = ctx.ID().getText();
        for (var sig : ctx.methodSignature()) {
            iface.requiredMethods.add(sig.ID().getText());
        }
        interfaces.put(iface.name, iface);
        return null;
    }

    @Override
    public Object visitMainBlock(delphiParser.MainBlockContext ctx) {
        for (var s : ctx.stmt()) visit(s);
        return null;
    }

    @Override
    public Object visitClassDecl(delphiParser.ClassDeclContext ctx) {
        ClassDef cd = new ClassDef();
        cd.name = ctx.ID(0).getText();
        String superName = null;
        String implementsName = null;
        
        // Check for inheritance (: Parent)
        if (ctx.getChild(2) != null && ctx.getChild(2).getText().equals(":")) {
            superName = ctx.ID(1).getText();
            // Check for implements after inheritance
            if (ctx.ID().size() == 3) {
                implementsName = ctx.ID(2).getText();
            }
        } else if (ctx.getChild(2) != null && ctx.getChild(2).getText().equals("implements")) {
            // Just implements, no inheritance
            implementsName = ctx.ID(1).getText();
        }
        
        cd.superName = superName;
        
        // Inherit from parent class
        if (cd.superName != null) {
            ClassDef parent = classes.get(cd.superName);
            if (parent != null) {
                cd.fields.addAll(parent.fields);
                cd.methods.putAll(parent.methods);
                cd.fieldVisibility.putAll(parent.fieldVisibility);
                if (cd.constructor == null) cd.constructor = parent.constructor;
            }
        }
        
        for (var m : ctx.classMember()) {
            if (m.fieldDecl() != null) {
                cd.fields.add(m.fieldDecl());
                String fieldName = m.fieldDecl().ID().getText();
                boolean isPrivate = m.fieldDecl().getText().startsWith("private");
                cd.fieldVisibility.put(fieldName, isPrivate);
            }
            if (m.constructorDecl() != null) cd.constructor = m.constructorDecl();
            if (m.destructorDecl() != null) cd.destructor = m.destructorDecl();
            if (m.methodDecl() != null) cd.methods.put(m.methodDecl().ID().getText(), m.methodDecl());
        }
        
        // Check interface implementation
        if (implementsName != null) {
            InterfaceDef iface = interfaces.get(implementsName);
            if (iface == null) {
                throw new RuntimeException("Interface " + implementsName + " not found");
            }
            for (String required : iface.requiredMethods) {
                if (!cd.methods.containsKey(required)) {
                    throw new RuntimeException("Class " + cd.name + " must implement method " + required + " from interface " + implementsName);
                }
            }
        }
        
        classes.put(cd.name, cd);
        return null;
    }

    @Override
    public Object visitVarDeclStmt(delphiParser.VarDeclStmtContext ctx) {
        String id = ctx.ID().getText();
        declareVariable(id, null);
        return null;
    }

    @Override
    public Object visitAssignStmt(delphiParser.AssignStmtContext ctx) {
        Object val = visit(ctx.expr());
        
        // Check if it's obj.field := value
        if (ctx.ID().size() == 2) {
            String objName = ctx.ID(0).getText();
            String fieldName = ctx.ID(1).getText();
            Object o = globals.get(objName);
            if (!(o instanceof Instance)) throw new RuntimeException("Not an object: " + objName);
            Instance inst = (Instance)o;
            
            // Check if field is private and we're accessing from outside
            Boolean isPrivate = inst.klass.fieldVisibility.get(fieldName);
            if (isPrivate != null && isPrivate && currentThis != inst) {
                throw new RuntimeException("Cannot assign to private field '" + fieldName + "' from outside class");
            }
            inst.fields.put(fieldName, val);
        } else {
            // Regular variable assignment
            String id = ctx.ID(0).getText();
            assign(id, val);
        }
        return null;
    }

    @Override
    public Object visitObjStmt(delphiParser.ObjStmtContext ctx) {
        if (ctx.getText().contains("new")) {
            String var = ctx.ID(0).getText();
            String cname = ctx.ID(1).getText();
            ClassDef cd = classes.get(cname);
            if (cd == null) throw new RuntimeException("Unknown class: " + cname);
            Instance inst = new Instance(cd);
            for (var f : cd.fields) inst.fields.put(f.ID().getText(), null);
            if (cd.constructor != null) {
                Instance prevThis = currentThis;
                currentThis = inst;
                pushScope();
                // Bind constructor parameters
                List<Object> args = evalArgs(ctx.argList());
                int expected = (cd.constructor.paramList() == null) ? 0 : cd.constructor.paramList().param().size();
                if (expected != args.size()) {
                    throw new RuntimeException("Constructor argument count mismatch for " + cname + ": expected " + expected + ", got " + args.size());
                }
                if (cd.constructor.paramList() != null) {
                    var params = cd.constructor.paramList().param();
                    for (int i = 0; i < params.size(); i++) {
                        String paramName = params.get(i).ID().getText();
                        scopes.peek().put(paramName, args.get(i));
                    }
                }
                visit(cd.constructor.block());
                popScope();
                currentThis = prevThis;
            }
            allInstances.add(inst);
            globals.put(var, inst);
        } else {
            String objName = ctx.ID(0).getText();
            String method = ctx.ID(1).getText();
            Object o = globals.get(objName);
            if (!(o instanceof Instance)) throw new RuntimeException("Not an object: " + objName);
            Instance inst = (Instance)o;
            delphiParser.MethodDeclContext mctx = inst.klass.methods.get(method);
            if (mctx == null) throw new RuntimeException("Method not found: " + method + " in " + inst.klass.name);
            Instance prevThis = currentThis;
            currentThis = inst;
            pushScope();
            // Bind method parameters
            List<Object> args = evalArgs(ctx.argList());
            int expected = (mctx.paramList() == null) ? 0 : mctx.paramList().param().size();
            if (expected != args.size()) {
                throw new RuntimeException("Method argument count mismatch for " + method + ": expected " + expected + ", got " + args.size());
            }
            if (mctx.paramList() != null) {
                var params = mctx.paramList().param();
                for (int i = 0; i < params.size(); i++) {
                    String paramName = params.get(i).ID().getText();
                    scopes.peek().put(paramName, args.get(i));
                }
            }
            visit(mctx.block());
            popScope();
            currentThis = prevThis;
        }
        return null;
    }

    @Override
    public Object visitProcCallStmt(delphiParser.ProcCallStmtContext ctx) {
        callRoutine(ctx.ID().getText(), ctx.argList(), false);
        return null;
    }

    @Override
    public Object visitWhileStmt(delphiParser.WhileStmtContext ctx) {
        while (isTruthy(visit(ctx.expr()))) {
            boolean shouldBreak = false;
            pushScope();
            try {
                visit(ctx.block());
            } catch (ContinueSignal c) {
                // Continue loop.
            } catch (BreakSignal b) {
                shouldBreak = true;
            } finally {
                popScope();
            }
            if (shouldBreak) break;
        }
        return null;
    }

    @Override
    public Object visitForStmt(delphiParser.ForStmtContext ctx) {
        String id = ctx.ID().getText();
        int start = asInt(visit(ctx.expr(0)));
        int end = asInt(visit(ctx.expr(1)));
        boolean downTo = "downto".equals(ctx.getChild(4).getText());

        for (int i = start; downTo ? i >= end : i <= end; i += downTo ? -1 : 1) {
            boolean shouldBreak = false;
            pushScope();
            try {
                assign(id, i);
                visit(ctx.block());
            } catch (ContinueSignal c) {
                // Continue loop.
            } catch (BreakSignal b) {
                shouldBreak = true;
            } finally {
                popScope();
            }
            if (shouldBreak) break;
        }
        return null;
    }

    @Override
    public Object visitBreakStmt(delphiParser.BreakStmtContext ctx) {
        throw new BreakSignal();
    }

    @Override
    public Object visitContinueStmt(delphiParser.ContinueStmtContext ctx) {
        throw new ContinueSignal();
    }

    @Override
    public Object visitIoStmt(delphiParser.IoStmtContext ctx) {
        if (ctx.getText().startsWith("readln")) {
            String id = ctx.ID().getText();
            String line = null;
            if (scanner.hasNextLine()) line = scanner.nextLine();
            Integer v = 0;
            try { if (line != null) v = Integer.parseInt(line.trim()); } catch (Exception e) {}
            assign(id, v);
        } else {
            Object val = visit(ctx.expr());
            System.out.println(val == null ? "null" : val.toString());
        }
        return null;
    }

    @Override
    public Object visitExprStmt(delphiParser.ExprStmtContext ctx) {
        visit(ctx.expr());
        return null;
    }

    @Override
    public Object visitBlock(delphiParser.BlockContext ctx) {
        for (var s : ctx.stmt()) visit(s);
        return null;
    }

    @Override
    public Object visitAddSub(delphiParser.AddSubContext ctx) {
        Object l = visit(ctx.expr(0));
        Object r = visit(ctx.expr(1));
        String op = ctx.op.getText();
        if (l instanceof String || r instanceof String) return String.valueOf(l) + String.valueOf(r);
        int li = asInt(l);
        int ri = asInt(r);
        return op.equals("+") ? (li + ri) : (li - ri);
    }

    @Override
    public Object visitMulDiv(delphiParser.MulDivContext ctx) {
        Object l = visit(ctx.expr(0));
        Object r = visit(ctx.expr(1));
        String op = ctx.op.getText();
        int li = asInt(l);
        int ri = asInt(r);
        return op.equals("*") ? (li * ri) : (li / (ri==0?1:ri));
    }

    @Override
    public Object visitAtomExpr(delphiParser.AtomExprContext ctx) {
        return visit(ctx.atom());
    }

    @Override
    public Object visitAtom(delphiParser.AtomContext ctx) {
        if (ctx.INT() != null) return Integer.parseInt(ctx.INT().getText());
        if (ctx.STRING() != null) {
            String s = ctx.STRING().getText();
            return s.substring(1, s.length()-1).replaceAll("\\\\\"","\"");
        }
        if (ctx.ID() != null) {
            if (ctx.getChildCount() >= 3 && "(".equals(ctx.getChild(1).getText())) {
                String fn = ctx.ID(0).getText();
                return callRoutine(fn, ctx.argList(), true);
            }
            if (ctx.ID().size() == 2) {
                String a = ctx.ID(0).getText();
                String b = ctx.ID(1).getText();
                Object o = globals.get(a);
                if (!(o instanceof Instance)) throw new RuntimeException("Not an object: " + a);
                Instance inst = (Instance)o;
                // Check if field is private and we're accessing from outside
                Boolean isPrivate = inst.klass.fieldVisibility.get(b);
                if (isPrivate != null && isPrivate && currentThis != inst) {
                    throw new RuntimeException("Cannot access private field '" + b + "' from outside class");
                }
                return inst.fields.get(b);
            }
            String id = ctx.ID(0).getText();
            return lookup(id);
        }
        if (ctx.expr() != null) return visit(ctx.expr());
        return null;
    }
}
