# Delphi Project

## Team Members
- Krishna Chaitanya Kolipakula (UFID: 94059870)
- Karthikeya Ruthvik Pakki (UFID: 52291889)

## Overview
This project extends Pascal with object-oriented programming features including classes, objects, constructors, destructors, and encapsulation. The implementation uses ANTLR4 for parsing and includes a Java-based interpreter. The syntax follows Pascal conventions with begin/end blocks and := assignment operator.

## What Works

### Core Features
- Classes and class definitions
- Object creation using the new keyword
- Constructors that are automatically called when objects are created
- Destructors that are automatically called at program end
- Encapsulation with private and public field modifiers
- Methods (procedures) that can be called on objects
- Input functionality using readln() for reading integers
- Output functionality using writeln() for printing integers

### Bonus Features
- Inheritance where child classes can inherit from parent classes
- Interfaces with runtime enforcement - classes must implement all interface methods

## Project Structure
- src/main/antlr4/delphi.g4 - The ANTLR4 grammar file
- src/main/java/Interpreter.java - The interpreter implementation
- src/main/java/Main.java - The main entry point
- tests/test1.pas - Test for basic class features and I/O
- tests/test2.pas - Test for encapsulation and destructors
- tests/test3.pas - Test for inheritance
- tests/test5.pas - Test for multiple objects and arithmetic
- tests/test6.pas - Test for multiple fields in a class
- tests/test7.pas - Test for private field access control
- tests/test_private_fail.pas - Negative test showing private access error
- tests/test_main_block.pas - Test for Pascal-style main block with trailing dot
- tests/test_params.pas - Test for parameter passing in constructors and methods
- tests/test_interface.pas - Test for interface implementation
- tests/test_interface_fail.pas - Negative test showing interface enforcement
- pom.xml - Maven build configuration

## Prerequisites
- Java 11 or higher
- Maven 3.6 or higher

## How to Build
Run the following command in the project directory:
```
mvn clean compile
```

This will generate the parser and lexer from the grammar file and compile all Java sources.

## How to Run

### Using Maven
```
mvn exec:java -Dexec.args="tests/test1.pas"
```

### Using Java directly
```
java -cp "target/classes:target/generated-sources/antlr4:~/.m2/repository/org/antlr/antlr4-runtime/4.11.1/antlr4-runtime-4.11.1.jar" Main tests/test1.pas
```

## Test Cases

### test1.pas
Tests basic class definition, constructor with input, and method with output.
- Input: An integer (e.g., 42)
- Output: The same integer

### test2.pas
Tests encapsulation with private fields, multiple methods, and destructor.
- Input: None
- Output: 1 (from increment and print), then 0 (from destructor)

### test3.pas
Tests inheritance where a child class inherits fields and methods from a parent class.
- Input: An integer (e.g., 5)
- Output: The same integer

### test5.pas
Tests multiple objects with arithmetic operations.
- Input: None
- Output: 30, 20

### test6.pas
Tests multiple fields in a class.
- Input: None
- Output: 10, 20

### test7.pas
Tests private field access control with comments showing blocked access.
- Input: None
- Output: 42

### test_private_fail.pas
Negative test demonstrating runtime error when accessing private fields from outside.
- Input: None
- Output: Runtime error (private field access violation)

### test_main_block.pas
Tests Pascal-style main block with begin...end. syntax.
- Input: None
- Output: 99

### test_params.pas
Tests parameter passing in constructors and methods.
- Input: None
- Output: 10, 15, 0

### test_interface.pas
Tests interface declaration and implementation with enforcement.
- Input: None
- Output: 100, 0

### test_interface_fail.pas
Negative test demonstrating error when class doesn't implement required interface methods.
- Input: None
- Output: Runtime error (missing interface method)

## Running Individual Tests

For tests that require input, provide it via echo:
```
echo "42" | mvn exec:java -Dexec.args="tests/test1.pas"
```

For tests without input:
```
mvn exec:java -Dexec.args="tests/test2.pas"
mvn exec:java -Dexec.args="tests/test5.pas"
mvn exec:java -Dexec.args="tests/test_params.pas"
```

## Notes
- Fields can be marked as private or public (default is public if not specified)
- Private fields cannot be accessed from outside the class
- The destructor is called automatically at the end of program execution for all created objects
- Inheritance copies parent fields and methods to child classes at class definition time
- Parameter passing is supported for constructors and methods
- Optional Pascal-style main block is supported: begin ... end. (with optional trailing dot)
