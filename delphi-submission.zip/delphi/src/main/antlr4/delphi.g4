grammar delphi;

program: (interfaceDecl | classDecl | stmt)* mainBlock? EOF ;

mainBlock: 'begin' stmt* 'end' '.'? ;

classDecl: 'class' ID (':' ID)? ('implements' ID)? 'begin' classMember* 'end' ';'? ;
interfaceDecl: 'interface' ID 'begin' methodSignature* 'end' ';'? ;
classMember: fieldDecl | methodDecl | constructorDecl | destructorDecl ;
methodSignature: 'procedure' ID '(' paramList? ')' ';' ;

fieldDecl: ('private' | 'public')? 'var' ID ':' type ';' ;
methodDecl: 'procedure' ID '(' paramList? ')' block ;
constructorDecl: 'constructor' '(' paramList? ')' block ;
destructorDecl: 'destructor' '(' ')' block ;

paramList: param (',' param)* ;
param: ID ':' type ;

type: 'integer' | ID ;

stmt: varDeclStmt | assignStmt | exprStmt | ioStmt | objStmt | ';' ;
varDeclStmt: 'var' ID ':' type ';' ;
assignStmt: (ID | ID '.' ID) ':=' expr ';' ;
exprStmt: expr ';' ;
objStmt: ID ':=' 'new' ID '(' argList? ')' ';' | ID '.' ID '(' argList? ')' ';' ;
ioStmt: 'readln' '(' ID ')' ';' | 'writeln' '(' expr ')' ';' ;

block: 'begin' stmt* 'end' ;

argList: expr (',' expr)* ;

expr: expr op=('*'|'/') expr   # MulDiv
    | expr op=('+'|'-') expr   # AddSub
    | atom                     # AtomExpr
    ;

atom: INT
    | STRING
    | ID ('.' ID)?
    | '(' expr ')'
    ;

ID: [a-zA-Z_][a-zA-Z0-9_]* ;
INT: [0-9]+ ;
STRING: '"' (~["\\] | '\\' .)* '"' ;
WS: [ \t\r\n]+ -> skip ;
LINE_COMMENT: '//' ~[\r\n]* -> skip ;
